import React from 'react'
import Hero from '../src/components/Hero'

const Home = () => {
  return (
    <>
        <Hero />
    </>
  )
}

export default Home